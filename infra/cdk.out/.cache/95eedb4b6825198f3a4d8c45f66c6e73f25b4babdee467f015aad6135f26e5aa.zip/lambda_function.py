import json
import boto3
import os
import requests
from decimal import Decimal

# Import shared libraries
from ff_standings import StandingsService
from ff_utils.dynamodb import convert_floats_to_decimal

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    """
    Historical data backfill Lambda:
    1. Fetch current NFL state to determine completed weeks
    2. For each completed week, fetch matchup data from Sleeper
    3. Store league data (users, rosters, players) if not already cached
    4. Calculate and store standings directly using shared library
    """
    
    try:
        # Initialize environment variables
        league_id = os.environ['SLEEPER_LEAGUE_ID']
        league_data_table = dynamodb.Table(os.environ['LEAGUE_DATA_TABLE'])
        weekly_standings_table = dynamodb.Table(os.environ['WEEKLY_STANDINGS_TABLE'])
        overall_standings_table = dynamodb.Table(os.environ['OVERALL_STANDINGS_TABLE'])
        
        # Initialize shared standings service (no persistent cache for Lambda)
        dynamodb_tables = {
            'league_data': league_data_table,
            'weekly_standings': weekly_standings_table,
            'overall_standings': overall_standings_table
        }
        standings_service = StandingsService(dynamodb_tables, enable_persistent_cache=False)
        
        print(f"Starting historical backfill for league {league_id}")
        
        # Step 1: Get current NFL state to determine completed weeks
        nfl_state = get_nfl_state()
        current_week = nfl_state.get('week', 1)
        season = nfl_state.get('season', '2025')
        
        print(f"NFL State - Season: {season}, Current Week: {current_week}")
        
        # Step 2: Cache league reference data (users, rosters, players)
        cache_league_data(league_id, league_data_table, season)
        
        # Step 3: Process each completed week (weeks 1 through current_week - 1)
        completed_weeks = list(range(1, current_week))  # Don't include current week if in progress
        
        if not completed_weeks:
            print("No completed weeks to backfill")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'No completed weeks to backfill',
                    'current_week': current_week
                })
            }
        
        print(f"Backfilling weeks: {completed_weeks}")
        
        # Process each week
        for week in completed_weeks:
            print(f"Processing week {week}")
            
            # Fetch and store matchup data for this week
            matchups = fetch_week_matchups(league_id, week)
            store_week_matchups(league_data_table, season, week, matchups)
            
            # Calculate and store standings directly using shared library
            try:
                weekly_results = standings_service.calculate_and_store(
                    matchups,
                    season, 
                    week,
                    include_player_details=True  # Include full player details for historical processing
                )
                print(f"Processed {len(weekly_results)} teams for week {week}")
            except Exception as e:
                print(f"Failed to calculate standings for week {week}: {e}")
                raise
            
            print(f"Completed week {week}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Historical backfill completed for {len(completed_weeks)} weeks',
                'weeks_processed': completed_weeks,
                'season': season
            })
        }
        
    except Exception as e:
        print(f"Historical backfill error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Historical backfill failed',
                'details': str(e)
            })
        }

def get_nfl_state():
    """Fetch current NFL state from Sleeper API"""
    try:
        response = requests.get('https://api.sleeper.app/v1/state/nfl', timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Failed to fetch NFL state: {e}")
        raise

def cache_league_data(league_id, table, season):
    """Cache users, rosters, and players data in DynamoDB"""
    
    # Cache users
    print("Caching users data...")
    users = fetch_sleeper_data(f'https://api.sleeper.app/v1/league/{league_id}/users')
    for user in users:
        table.put_item(Item=convert_floats_to_decimal({
            'data_type': 'users',
            'id': user['user_id'],
            'season': season,
            'data': user
        }))
    print(f"Cached {len(users)} users")
    
    # Cache rosters
    print("Caching rosters data...")
    rosters = fetch_sleeper_data(f'https://api.sleeper.app/v1/league/{league_id}/rosters')
    for roster in rosters:
        table.put_item(Item=convert_floats_to_decimal({
            'data_type': 'rosters',
            'id': str(roster['roster_id']),
            'season': season,
            'data': roster
        }))
    print(f"Cached {len(rosters)} rosters")
    
    # Cache league info
    print("Caching league info...")
    league_info = fetch_sleeper_data(f'https://api.sleeper.app/v1/league/{league_id}')
    table.put_item(Item=convert_floats_to_decimal({
        'data_type': 'league_info',
        'id': 'league',
        'season': season,
        'data': league_info
    }))
    print("Cached league info")
    
    # Cache players using chunked storage (check if already exists to avoid unnecessary API call)
    try:
        # Check for chunked players metadata first (new format)
        existing_meta = table.get_item(
            Key={'data_type': 'players_meta', 'id': f'nfl_players_{season}'}
        )
        
        # If no chunked metadata, check for old single-item format
        if 'Item' not in existing_meta:
            existing_players = table.get_item(
                Key={'data_type': 'players', 'id': 'nfl_players'}
            )
            
            if 'Item' not in existing_players:
                print("Caching players data using chunked storage...")
                players_data = fetch_sleeper_data('https://api.sleeper.app/v1/players/nfl')
                
                # Use chunked storage approach (same as API handler)
                players_list = [{'player_id': pid, **data} for pid, data in players_data.items()]
                chunk_size = 400
                total_chunks = (len(players_list) + chunk_size - 1) // chunk_size
                chunks_stored = 0
                
                # Store players in chunks
                for i in range(0, len(players_list), chunk_size):
                    chunk = players_list[i:i + chunk_size]
                    chunk_id = f"{season}_chunk_{i // chunk_size + 1}"
                    
                    try:
                        table.put_item(Item=convert_floats_to_decimal({
                            'data_type': 'players_chunk',
                            'id': chunk_id,
                            'season': season,
                            'chunk_number': i // chunk_size + 1,
                            'total_chunks': total_chunks,
                            'players': chunk,
                            'player_count': len(chunk)
                        }))
                        chunks_stored += 1
                        print(f"Cached chunk {chunks_stored}/{total_chunks} ({len(chunk)} players)")
                    except Exception as chunk_error:
                        print(f"Warning: Failed to store chunk {chunks_stored + 1}: {chunk_error}")
                        continue
                
                # Store metadata
                try:
                    table.put_item(Item=convert_floats_to_decimal({
                        'data_type': 'players_meta',
                        'id': f'nfl_players_{season}',
                        'season': season,
                        'total_players': len(players_list),
                        'total_chunks': total_chunks,
                        'chunks_stored': chunks_stored,
                        'chunk_size': chunk_size,
                        'last_updated': 'backfill',
                        'storage_strategy': 'chunked_v1'
                    }))
                except Exception as meta_error:
                    print(f"Warning: Failed to store players metadata: {meta_error}")
                    
                print(f"Cached {len(players_list)} players in {chunks_stored} chunks")
            else:
                print("Players data already cached (legacy format), skipping")
        else:
            print("Players data already cached (chunked format), skipping")
    except Exception as e:
        print(f"Warning: Failed to cache players data: {e}")
        # Continue without players data for now

def fetch_sleeper_data(url):
    """Fetch data from Sleeper API with error handling"""
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Failed to fetch {url}: {e}")
        raise

def fetch_week_matchups(league_id, week):
    """Fetch matchup data for a specific week"""
    url = f'https://api.sleeper.app/v1/league/{league_id}/matchups/{week}'
    return fetch_sleeper_data(url)

def store_week_matchups(table, season, week, matchups):
    """Store weekly matchup data in DynamoDB"""
    try:
        # Store matchups data for this week
        table.put_item(Item=convert_floats_to_decimal({
            'data_type': 'matchups',
            'id': f'{season}_{week}',
            'season': season,
            'week': week,
            'data': matchups
        }))
        print(f"Stored matchups for week {week}")
    except Exception as e:
        print(f"Failed to store week {week} matchups: {e}")
        raise


def decimal_default(obj):
    """JSON serializer for DynamoDB Decimal types"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError