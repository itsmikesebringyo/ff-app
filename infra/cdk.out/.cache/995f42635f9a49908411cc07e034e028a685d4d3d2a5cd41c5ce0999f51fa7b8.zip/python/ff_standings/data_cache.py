"""
Data caching for players and team names
"""

import logging
import time
import boto3
from typing import Dict, Any

logger = logging.getLogger(__name__)


class DataCache:
    def __init__(self, league_data_table, enable_persistent_cache: bool = False):
        self.league_data_table = league_data_table
        self.enable_persistent_cache = enable_persistent_cache
        self._players_data = None
        self._team_names = None
        self._cache_timestamp = 0
        self.cache_ttl = 3600 if enable_persistent_cache else 0
    
    def _is_cache_valid(self) -> bool:
        if not self.enable_persistent_cache:
            return False
        if self._players_data is None or self._team_names is None:
            return False
        return (time.time() - self._cache_timestamp) < self.cache_ttl
    
    def get_players_data(self) -> Dict[str, Any]:
        if self._is_cache_valid():
            return self._players_data
        try:
            players_data = self._load_chunked_players_data()
            if players_data:
                self._players_data = players_data
            else:
                self._players_data = self._load_legacy_players_data() or {}
            if self.enable_persistent_cache:
                self._cache_timestamp = time.time()
            return self._players_data
        except Exception as e:
            logger.error(f"Error loading players data: {e}")
            return {}
    
    def _load_chunked_players_data(self) -> Dict[str, Any]:
        try:
            meta_response = self.league_data_table.get_item(Key={'data_type': 'players_meta', 'id': 'nfl_players_2025'})
            if 'Item' not in meta_response:
                return {}
            meta = meta_response['Item']
            total_chunks = int(meta.get('total_chunks', 0))
            chunk_response = self.league_data_table.query(KeyConditionExpression=boto3.dynamodb.conditions.Key('data_type').eq('players_chunk'))
            chunks = chunk_response.get('Items', [])
            chunks.sort(key=lambda x: int(x.get('chunk_number', 0)))
            players_data = {}
            for chunk in chunks:
                for player in chunk.get('players', []):
                    pid = player.get('player_id')
                    if pid:
                        players_data[pid] = {k: v for k, v in player.items() if k != 'player_id'}
            return players_data if total_chunks else {}
        except Exception as e:
            logger.error(f"Error loading chunked players data: {e}")
            return {}
    
    def _load_legacy_players_data(self) -> Dict[str, Any]:
        try:
            response = self.league_data_table.get_item(Key={'data_type': 'players', 'id': 'nfl_players'})
            return response['Item']['data'] if 'Item' in response else {}
        except Exception as e:
            logger.error(f"Error loading legacy players data: {e}")
            return {}
    
    def get_team_names(self) -> Dict[str, str]:
        if self._is_cache_valid():
            return self._team_names
        team_names = {}
        try:
            rosters_response = self.league_data_table.query(KeyConditionExpression=boto3.dynamodb.conditions.Key('data_type').eq('rosters'))
            roster_to_user = {}
            for item in rosters_response.get('Items', []):
                roster_data = item['data']
                roster_to_user[str(roster_data['roster_id'])] = roster_data.get('owner_id')
            users_response = self.league_data_table.query(KeyConditionExpression=boto3.dynamodb.conditions.Key('data_type').eq('users'))
            user_to_name = {}
            for item in users_response.get('Items', []):
                user_data = item['data']
                uid = user_data['user_id']
                user_to_name[uid] = user_data.get('display_name') or user_data.get('username') or f"Team {uid}"
            for roster_id, uid in roster_to_user.items():
                team_names[roster_id] = user_to_name.get(uid, f"Team {roster_id}")
            self._team_names = team_names
            if self.enable_persistent_cache:
                self._cache_timestamp = time.time()
            return team_names
        except Exception as e:
            logger.error(f"Error loading team names: {e}")
            return {}
    
    def load_all_cache(self) -> None:
        self.get_players_data()
        self.get_team_names()


