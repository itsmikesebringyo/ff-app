"""
Core "vs everyone" standings calculation logic
"""

import logging
from operator import itemgetter
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class StandingsCalculator:
    def __init__(self):
        self.position_labels = ['QB', 'RB', 'RB', 'WR', 'WR', 'TE', 'FLEX', 'DST']
    
    def build_team_roster(self, matchup: Dict[str, Any], players_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        roster = []
        starters = matchup.get('starters', [])
        players_points = matchup.get('players_points', {})
        for i, player_id in enumerate(starters):
            position = self.position_labels[i] if i < len(self.position_labels) else 'FLEX'
            points = players_points.get(player_id, 0.0)
            if players_data and player_id in players_data:
                player_info = players_data[player_id]
                first_name = player_info.get('first_name', '')
                last_name = player_info.get('last_name', '')
                player_name = f"{first_name} {last_name}".strip()
                if not player_name:
                    player_name = player_id
            else:
                player_name = player_id
            roster.append({'position': position, 'player': player_name, 'points': float(points)})
        return roster
    
    def calculate_weekly_vs_everyone(self, matchups: List[Dict[str, Any]], team_names: Dict[str, str], players_data: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        team_scores = {}
        for matchup in matchups:
            roster_id = str(matchup['roster_id'])
            points = float(matchup.get('points', 0))
            roster = self.build_team_roster(matchup, players_data) if players_data else []
            team_scores[roster_id] = {
                'roster_id': roster_id,
                'team_name': team_names.get(roster_id, f'Team {roster_id}'),
                'points': points,
                'roster': roster
            }
        sorted_teams = sorted(team_scores.values(), key=itemgetter('points'), reverse=True)
        total_teams = len(sorted_teams)
        weekly_results = []
        for rank, team in enumerate(sorted_teams, 1):
            wins = total_teams - rank
            losses = rank - 1
            weekly_results.append({
                'roster_id': team['roster_id'],
                'team_name': team['team_name'],
                'rank': rank,
                'points': team['points'],
                'wins': wins,
                'losses': losses,
                'roster': team['roster']
            })
        logger.info(f"Calculated vs everyone standings for {len(weekly_results)} teams")
        return weekly_results


